const adminRoutes = require('express').Router();

adminRoutes.get("/profile", (req, res) => {
  res.status(200).json({ message: "Admin API hit" });
});

module.exports = adminRoutes;
