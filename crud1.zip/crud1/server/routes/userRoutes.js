
const express = require('express');
const { getUsers, addUsers, deleteUsers, searchUser, userUpdate } = require('./controllers/userControllers');

const userRoutes = express.Router();

userRoutes.get("/getusers",getUsers );
//getuser
userRoutes.post("/addusers",addUsers);
//adduser
userRoutes.delete('/deleteusers/:userid', deleteUser);
//deleteuser
userRoutes.get('/searchusers', searchUser);
//searchuser

userRoutes.put('/updateUser', userUpdate);
//updateuser

module.exports = { userRoutes };
