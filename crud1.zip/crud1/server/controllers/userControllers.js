
const users = [
    { id: 1, name: "Haritha", age: 26, email: "haritha@gmail.com" },
    { id: 2, name: "Chippy", age: 27, email: "chikku@example.com" }
  ];
  
  const getUsers = (req, res) => {
    res.json({ message: 'Users fetched', users });
  };
  
  const addUser = (req, res) => {
    try {
      console.log(req.body, "req.body");
      users.push(req.body);
      res.status(201).json({ message: "User added successfully", data: users });
    } catch (error) {
      res.status(500).json({ message: "Internal Server Error", error: error.message });
    }
  };
  
  const deleteUser = (req, res) => {
    console.log(req.params.userid, "id");
    users = users.filter((user) => user.id !== parseInt(req.params.userid));
    res.status(204).json({ message: "User deleted successfully", users });
  };
  
  const searchUser = (req, res) => {
    try {
      console.log(req.query.name);
      const searchResult = users.filter((user) => user.name === req.query.name);
      res.status(200).json(searchResult);
    } catch (error) {
      res.status(500).json({ message: "Internal Server Error", error: error.message });
    }
  };
  
  const userUpdate = (req, res) => {
    try {
      const { userid } = req.params;
      const { name, email, age } = req.body;
      console.log(userid, name, email, age);
      const updatedUsers = users.map((user) => {
        if (user.id === parseInt(userid)) {
          user.name = name;
          user.email = email;
          user.age = age;
        }
        return user;
      });
      res.status(200).json({ message: "User updated successfully", data: updatedUsers });
    } catch (error) {
      res.status(500).json({ message: "Internal Server Error", error: error.message });
    }
  };
  
  module.exports = { getUsers, addUser, deleteUser, searchUser, userUpdate };
  
  
  