const express = require("express");
const app = express();

const userRoutes = require('./routes/userRoutes');
const adminRoutes = require("./routes/adminRoutes");

app.use(express.json());


app.use((req, res, next) => {
  console.log('App use hit');
  next();
});

app.use("/users", userRoutes);
app.use("/admin", adminRoutes);

app.listen(3002, () => {
  console.log("Server started on port 3002");
});

